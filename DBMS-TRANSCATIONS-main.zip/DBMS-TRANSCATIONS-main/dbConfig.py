# Database connection configuration
DB_NAME = 'dbms_transactions_db'
DB_CONFIG = {
    'dbname': DB_NAME,
    'user': 'postgres',
    'password': 'Koushika@2003',
    'host': 'localhost',
    'port': '5433'
}